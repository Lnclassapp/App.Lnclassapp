# Lnclass — Évaluations « La propriété de Thalès » (Maths 3e)

Deux évaluations interactives corrigées automatiquement, format cahier Seyès, adaptées ordinateur, tablette et téléphone.

| Fichier | Contenu |
|---|---|
| `interrogation-thales.html` | Interrogation · 4 exercices · 20 points · 30 min |
| `devoir-thales.html` | Devoir format BEPC · 4 exercices · 20 points · durée conseillée 2 h, sans chronomètre |

## Utilisation rapide
Ces deux fichiers sont **autonomes** : il suffit de les ouvrir dans un navigateur (aucune installation).

Pour les publier en ligne : activer **GitHub Pages** (Settings → Pages → branche `main`), puis partager :
- `https://<compte>.github.io/<dépôt>/interrogation-thales.html`
- `https://<compte>.github.io/<dépôt>/devoir-thales.html`

## Fonctionnement
- L'élève répond directement sur la fiche, puis clique sur « Rendre ma copie » (double confirmation) : note /20, détail par exercice et correction de chaque question.
- Devoir : pas de chronomètre ; durée conseillée 2 h. Une seule tentative : l'élève vérifie ses réponses, puis rend sa copie.
- Les réponses sont enregistrées dans le navigateur de l'élève.
- Bouton « Signaler une erreur » : l'enseignant coche les mots erronés et envoie un rapport à l'équipe Lnclass (contact@lnclass.com).

## Sources (dossier `sources/`)
Versions modifiables : `Interrogation Thales.dc.html`, `Devoir Thales.dc.html` + `support.js` + `signalement-erreurs/lnclass-signalement.js`, à garder dans la même arborescence et à servir via un serveur web (ou GitHub Pages).
