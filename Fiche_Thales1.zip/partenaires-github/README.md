# Lnclass — Interrogation « La propriété de Thalès » (Maths 3e)

Interrogation interactive sur 20 points (4 exercices), corrigée automatiquement. Format cahier Seyès, adapté ordinateur, tablette et téléphone.

## Utilisation rapide
`interrogation-thales.html` est un fichier **autonome** : il suffit de l'ouvrir dans un navigateur (aucune installation).

Pour le publier en ligne : activer **GitHub Pages** (Settings → Pages → branche `main`), puis partager l'adresse
`https://<compte>.github.io/<dépôt>/interrogation-thales.html`.

## Contenu
- Exercice 1 — QCM (4 pts)
- Exercice 2 — Vrai ou faux avec figure (4 pts)
- Exercice 3 — Calcul de longueurs, configuration papillon (6 pts)
- Exercice 4 — Réciproque de Thalès : la charpente (6 pts)

L'élève clique sur « Rendre ma copie » (double confirmation) → note /20, détail par exercice et correction de chaque question. Les réponses sont enregistrées dans le navigateur.

Bouton « Signaler une erreur » : l'enseignant coche les mots erronés et envoie un rapport à l'équipe Lnclass (contact@lnclass.com).

## Sources (dossier `sources/`)
Version modifiable : `Interrogation Thales.dc.html` + `support.js` + `signalement-erreurs/lnclass-signalement.js`, à garder dans la même arborescence et à servir via un serveur web (ou GitHub Pages).
